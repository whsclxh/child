# SoftKey

## Version
0.0.1

## Dependencies
- Jquery 1.11

## About
A JQuery plugin to generate a keyboard on screen